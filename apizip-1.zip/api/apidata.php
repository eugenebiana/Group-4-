<?php
    $DB_host = "localhost";
    $DB_user = "root";
    $DB_pass = "admin123";
    $DB_name = "emailverification";
    $db_port = 3307;

    $conn;

    try{
        $conn = mysqli_connect($DB_host, $DB_user, $DB_pass, $DB_name, $db_port);
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();  
    }
?>