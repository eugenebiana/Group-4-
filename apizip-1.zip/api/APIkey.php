
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get API Key</title>
</head>
<body style="place-items: center;">
    <h1>Welcome to Email Verification API</h1>
    <form action="APIkey.php" method="post" 
    style="text-align: center; border: 1px solid black;
    padding: 30px; font-size: 30px; border-radius: 5px;">
        <h3>User Signup</h3>
       <label for="">First Name:</label>
       <input name="fName" required type="text" style="font-size: 20px;
       padding: 10px; border-radius: 7px;"><br><br>
       <label for="">Last Name:</label>
       <input name="lName" required type="text" style="font-size: 20px;
       padding: 10px;  border-radius: 7px;"><br><br>
       <label for="">Email Add.:</label>
       <input type="text" required name="email" style="font-size: 20px;
       padding: 10px;  border-radius: 7px;"><br><br>
       <button name="getKey" type="submit" value="Get API Key" style="font-size: 25px;
       padding: 10px; background-color: green; color: white; font-weight: bold;
       border-radius: 7px;">Get Your API key</button>
       <p style="font-size: 15px;"><b>Note:</b> Do not share your API key❗</p>
    </form>    
</body>
</html>
<?php
if(isset($_POST["getKey"])) {
    $first_name = $_POST['fName'] ?? '';
   $last_name = $_POST['lName'] ?? '';
   $email = $_POST['email'] ?? '';

   $ch = curl_init('http://localhost/api_tester/newTest.php');

   curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['client_email' => $email,
'fName' => $first_name, 'lName' => $last_name]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
]);
$response = curl_exec($ch);
$data = json_decode($response, true);
if ($response === false) {
    echo 'Curl error: ' . curl_error($ch);
} 
if (isset($data['APIkey'])) {
    $apiKey = $data['APIkey'];
} else {
    echo "API Key not found in the response.";
}
curl_close($ch);
    header("location: test.php");
}
?>