<?php
include("apidata.php");
header('Content-Type: application/json'); 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); 
    echo json_encode(['error' => 'Method Not Allowed. Use POST.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$receiver = $input['email'] ?? null; 
$domain_name = $input['domain_name'] ?? null; 
$subject = $input['subject'] ?? null; 
$sender_email = $input['sender_email'] ?? null; 
$sender_password = $input['sender_password'] ?? null; 
$key = $input['API_Key'] ?? null; 

if (isset($receiver, $domain_name, $subject, $key, $sender_email, $sender_password, )) {
    $mail = new PHPMailer(true);
    try {
        $code = random_int(100000, 999999); 
        $sql = "SELECT * FROM `api` WHERE `API_key` = ?";
        $stmt = mysqli_prepare( $conn, $sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $key); 
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) > 0) {
                $sql = "INSERT INTO verify (Email, Domain, Subject, Sender, API_Key, Code)
                        VALUES (?, ?, ?, ?, ?, ?)";
                $insert_stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($insert_stmt, "ssssss", $receiver, $domain_name, $subject, $sender_email, $key, $code);
                mysqli_stmt_execute($insert_stmt);
                
                if (mysqli_stmt_affected_rows($insert_stmt) > 0) {
                    $mail->isSMTP();                                           
                    $mail->Host       = 'smtp.gmail.com';                     
                    $mail->SMTPAuth   = true;                                  
                    $mail->Username   = $sender_email;           
                    $mail->Password   = $sender_password;                
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;       
                    $mail->Port       = 587;                                   

                    $mail->setFrom($sender_email, $domain_name); 
                    $mail->addAddress($receiver);                               

                    $mail->isHTML(true);                                  
                    $mail->Subject = $subject;
                    $mail->Body = "Your verification code is <b>{$code}</b>";
                    $mail->AltBody = "Your verification code is {$code}";

                    $mail->send(); 

                    echo json_encode(['verification_code' => $code, 'success' => 'Verification code sent successfully.']);
                } else {
                    http_response_code(500);
                    echo json_encode(['error' => 'Failed to insert verification data.']);
                }
            } else {
                http_response_code(403); 
                echo json_encode(['error' => 'Unauthorized.']);
            }
            mysqli_stmt_close($stmt);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Database query preparation failed.']);
        }

    } catch (Exception $e) {
        http_response_code(500); 
        echo json_encode(['error' => "Error: {$e->getMessage()}"]);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields.']);
}
include("check.php");
?>
