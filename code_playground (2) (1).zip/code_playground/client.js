// Import the mysql2 library to interact with MySQL databases
const mysql = require('mysql2'); 

// Create a connection to the MySQL database with the specified configuration
const connection = mysql.createConnection({
    host: 'localhost',      // The hostname of the database server
    user: 'root',           // The username to connect to the database
    password: 'admin123',   // The password for the specified user
    database: 'loandb',     // The name of the database to connect to
    port: 3307              // The port number on which the MySQL server is running
});

// Connect to the database
connection.connect((err) => {
    if (err) {
        // If there is an error during connection, log the error stack
        console.error('Error connecting to the database: ', err.stack);
        return; // Exit the function if there is an error
    }
    // Log a success message with the thread ID of the connection
    console.log('Connected to database as id ' + connection.threadId);
});

// Function to insert a new user into the database
const insertUser   = (username, password) => {
    // SQL query to insert a new user with placeholders for values
    const query = 'INSERT INTO users (username, password) VALUES (?, ?)';
    
    // Execute the query with the provided username and password
    connection.query(query, [username, password], (err, results) => {
        if (err) {
            // If there is an error during insertion, log the error
            console.error('Error inserting user:', err);
            return; // Exit the function if there is an error
        }
        // Log the ID of the newly inserted user
        console.log('User  inserted with id: ', results.insertId);
    });
};

// Function to fetch all users from the database
const getUsers = () => {
    // SQL query to select all users from the users table
    const query = 'SELECT * FROM users';
    
    // Execute the query
    connection.query(query, (err, results) => {
        if (err) {
            // If there is an error during fetching, log the error
            console.error('Error fetching users:', err);
            return; // Exit the function if there is an error
        }
        // Log the results (list of users)
        console.log('Users:', results);
    });
};

// Insert a new user with the username "Name" and password "cafafa@ex.com"
insertUser ("Name", 'cafafa@ex.com');

// Fetch and log all users from the database
getUsers();

// Set a timeout to end the database connection after 1 second
setTimeout(() => {
    // End the connection to the database
    connection.end((err) => {
        if (err) {
            // If there is an error ending the connection, log the error
            console.error('Error ending the connection:', err);
            return; // Exit the function if there is an error
        }
        // Log a message indicating that the connection has been closed
        console.log('Connection Closed');
    });
}, 1000); // Delay of 1000 milliseconds (1 second) before ending the connection