   const express = require('express');
   const mysql = require('mysql2');
   const bodyParser = require('body-parser');
   const cors = require('cors');

   const app = express();
   app.use(cors()); 
   app.use(bodyParser.json());

   const pool = mysql.createPool({
       host: 'localhost',
       user: 'root',
       password: 'admin123',
       database: 'loandb',
       port: 3307,
       waitForConnections: true,
       connectionLimit: 10,
       queueLimit: 0
   });

   const WebSocket = require('ws');
const e = require('express');
   const wss = new WebSocket.Server({ port: 8080 });

   wss.on('connection', ws => {
       console.log('Client connected');
       ws.send('Welcome to WebSocket Server!');
   });

   app.post('/register', (req, res) => {
       const { username, password } = req.body;
       const query = 'INSERT INTO users (username, password) VALUES (?, ?)';
       
       pool.query(query, [username, password], (err, results) => {
           if (err) {
               console.error('Database error:', err);
               return res.status(500).json({ error: err.message });
           }
           console.log('User  registered with ID:', results.insertId);
           res.status(201).json({ userId: results.insertId });
       });
   });
   app.post('/login', (req, res) => {
       const { username, password } = req.body;
       const query = 'SELECT * FROM users WHERE username = ? AND password = ?';
       
       pool.query(query, [username, password], (err, results) => {
           if (err) {
               console.error('Database error:', err);
               return res.status(500).json({ error: err.message });
           }
           console.log('Uer Log in successfully:', results.getId);
           res.status(201).json({results.getId });
       });
   });
   app.post('/delete', (req, res) => {
       const { username, password } = req.body;
       const query = 'DELETE FROM users WHERE username = ? AND password = ?';
       
       pool.query(query, [username, password], (err, results) => {
           if (err) {
               console.error('Database error:', err);
               return res.status(500).json({ error: err.message });
           }
           console.log('Deleted:', results.getId);
           res.status(201).json({ userId: results.getId });
       });
   });
   app.post('/update', (req, res) => {
       const { username, password} = req.body;
       const query = 'UPDATE users SET password = ? WHERE username = ?';
       
       pool.query(query, [username, password,], (err, results) => {
           if (err) {
               console.error('Database error:', err);
               return res.status(500).json({ error: err.message });
           }
           console.log('Updated:', results.getId);
           res.status(201).json({ userId: results.getId });
       });
   });
   app.listen(3000, () => {
       console.log('Server is running on port 3000');
   });
    app.post('/applyLoan', (req, res) => {
    const { applicant, amount, term, interest, date, status, username } = req.body;
    if (!applicant || !amount || !term || !interest || !date || !status || !username) {
        return res.status(400).json({ error: 'All fields are required' });
    }
    const query = 'INSERT INTO ExistingLoan (Applicant, Amount, Term, Interest, loan_date, status, username) VALUES (?, ?, ?, ?, ?, ?, ?)';
    const values = [applicant, amount, term, interest, date, status, username];
    pool.query(query, values, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ userId: results.insertId }); 
    });
});
    app.post('/getLoan', (req, res) => {
    const { username } = req.body;
    const query = 'SELECT Applicant, Amount, Term, Interest, status FROM existingloan WHERE username = ?'; 
    const values = [username];
    pool.query(query, values, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'No loans found for this user.' });
        }
        res.status(200).json(results); 
    });
});

     app.use(cors({
      origin: 'http://127.0.0.1:5500' 
  }));
   